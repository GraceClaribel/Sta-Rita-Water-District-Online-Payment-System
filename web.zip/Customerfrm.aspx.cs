﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customerfrm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {

                //Binddropdownlist();
                btnsearch_Click(null, null);
                pnleditsave.Visible = false;
                pnllist.Visible = true;
            }
            catch (Exception ex)
            {
                string strmessage = "Page_Load() " + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
            }

        }
        //default inserted updated id admin
        if (ViewState["vs_personnelid"] == null)
        {
            ViewState["vs_personnelid"] = 1;
        }
    }
    private void Bindlist()
    {
        using (DataClassesDataContext dc = new DataClassesDataContext())
        {
            var res = from c in dc.Customers
                      join jinsby in dc.Personnels on c.InsertedById equals jinsby.Id into iinsby
                      from insby in iinsby.DefaultIfEmpty()
                      join jupdby in dc.Personnels on c.UpdatedById equals jupdby.Id into iupdby
                      from updby in iupdby.DefaultIfEmpty()
                      join jportalby in dc.Personnels on c.PortalActiveById equals jportalby.Id into iportalby
                      from portalby in iportalby.DefaultIfEmpty()
                      select new
                      {
                          c.AccCode,
                          c.Active,
                          c.Address1,
                          c.Address2,
                          c.Barangay,
                          c.City,
                          c.Country,
                          c.CustomerContactNo,
                          c.CustomerEmail,
                          c.CustomerName,
                          c.CustomerShortName,
                          c.HouseNoStreet,
                          c.Id,
                          InsertedBy = insby.FirstName + " " + insby.MiddleName + " " + insby.MiddleName,
                          c.InsertedDate,
                          UpdatedBy = updby.FirstName + " " + updby.MiddleName + " " + updby.MiddleName,
                          c.UpdatedDate,
                          c.Municipality,
                          c.Phone,
                          c.PortalActive,
                          Portalby = portalby.FirstName + " " + portalby.MiddleName + " " + portalby.MiddleName,
                          c.PortalActiveDate,
                          c.PortalPassword,
                          c.PortalUserName,
                          c.Province,
                          c.Remarks1,
                          c.Remarks2,
                          c.Reporting_Address,
                          c.Reporting_CustomerName,
                          c.Website,
                          c.ZipCode,
                          c.PSICCode,
                          c.Industry,
                          c.Region



                      };
            if (txtsearchcontains1.Text.Trim() != "")
            {
                string s1 = txtsearchcontains1.Text.Trim();
                res = res.Where(w => w.AccCode.Contains(s1) || w.Address1.Contains(s1) || w.Address2.Contains(s1)
                    || w.Barangay.Contains(s1) || w.City.Contains(s1) || w.Country.Contains(s1) || w.CustomerContactNo.Contains(s1)
                    || w.CustomerEmail.Contains(s1) || w.CustomerName.Contains(s1) || w.CustomerShortName.Contains(s1)
                    || w.HouseNoStreet.Contains(s1) || w.Industry.Contains(s1) || w.Municipality.Contains(s1) || w.Phone.Contains(s1)
                    || w.Portalby.Contains(s1) || w.PortalUserName.Contains(s1) || w.Province.Contains(s1) || w.PSICCode.Contains(s1)
                    || w.Region.Contains(s1) || w.Remarks1.Contains(s1) || w.Remarks2.Contains(s1) || w.Reporting_Address.Contains(s1)
                    || w.Reporting_CustomerName.Contains(s1) || w.Website.Contains(s1) || w.ZipCode.Contains(s1)

                    );
            }
            if (txtsearchcontains2.Text.Trim() != "")
            {
                string s1 = txtsearchcontains2.Text.Trim();
                res = res.Where(w => w.AccCode.Contains(s1) || w.Address1.Contains(s1) || w.Address2.Contains(s1)
                     || w.Barangay.Contains(s1) || w.City.Contains(s1) || w.Country.Contains(s1) || w.CustomerContactNo.Contains(s1)
                     || w.CustomerEmail.Contains(s1) || w.CustomerName.Contains(s1) || w.CustomerShortName.Contains(s1)
                     || w.HouseNoStreet.Contains(s1) || w.Industry.Contains(s1) || w.Municipality.Contains(s1) || w.Phone.Contains(s1)
                     || w.Portalby.Contains(s1) || w.PortalUserName.Contains(s1) || w.Province.Contains(s1) || w.PSICCode.Contains(s1)
                     || w.Region.Contains(s1) || w.Remarks1.Contains(s1) || w.Remarks2.Contains(s1) || w.Reporting_Address.Contains(s1)
                     || w.Reporting_CustomerName.Contains(s1) || w.Website.Contains(s1) || w.ZipCode.Contains(s1)

                     );
            }

            if (res.Any())
            {
                AspNetPager1.RecordCount = res.Count();
                lvlist.DataSource = res.Skip(AspNetPager1.StartRecordIndex - 1).Take(AspNetPager1.PageSize).ToList();
                lvlist.DataBind();
            }
            else
            {
                AspNetPager1.RecordCount = 0;
                lvlist.DataSource = null;
                lvlist.DataBind();

            }


        }
    }
    //private void Binddropdownlist()
    //{
    //    using (DataClassesDataContext dc = new DataClassesDataContext())
    //    {
    //        var vardept = dc.Departments;
    //        if (vardept.Any())
    //        {
    //            ddldepartment.DataSource = vardept.Select(s => new
    //            {
    //                text = s.DepartmentDesc,
    //                id = s.Id
    //            });
    //            ddldepartment.DataBind();

    //        }
    //        var varanalyst = dc.Personnels;
    //        if (varanalyst.Any())
    //        {
    //            ddlanalyst.DataSource = varanalyst.Select(s => new
    //            {
    //                id = s.Id,
    //                text = s.LastName + " " + s.FirstName + " " + s.MiddleName
    //            });
    //            ddlanalyst.DataBind();

    //        }

    //        var varunit = dc.Units;
    //        if (varunit.Any())
    //        {
    //            ddlunit.DataSource = varunit.Select(s => new
    //            {
    //                id = s.Id,
    //                text = s.UnitDesc
    //            });
    //            ddlunit.DataBind();
    //        }
    //        var varintru = dc.Instruments;
    //        if (varintru.Any())
    //        {
    //            ddlinstrument.DataSource = varintru.Select(s => new
    //            {
    //                id = s.Id,
    //                text = s.InstrumentDesc
    //            });
    //            ddlinstrument.DataBind();
    //        }
    //        ddldepartment.Items.Insert(0, "");
    //        ddlanalyst.Items.Insert(0, "");
    //        ddlunit.Items.Insert(0, "");
    //        ddlinstrument.Items.Insert(0, "");
    //    }
    //}
    public double? ValidateDouble(string text, ref string textError)
    {
        if (text == null)
        {
            return null;
        }

        double result;
        if (!double.TryParse(text, out result))
        {
            textError += "Invalid double input: " + text + Environment.NewLine;
            return null;
        }
        return result;
    }






    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
          
            Customer c = new Customer();

            c.AccCode = txtaccountingcode.Text.Trim(); ;
            c.Active = ckbactive.Checked;
            c.Address1 = txtadddress1.Text.Trim(); ;
            c.Address2 = txtaddress2.Text.Trim(); ;
            c.Barangay = txtbarangay.Text.Trim(); ;
            c.City = txtCity.Text.Trim();
            c.Country = txtcountry.Text.Trim();
            c.CustomerContactNo = txtcustomercontactno.Text.Trim();
            c.CustomerEmail = txtcustomeremail.Text.Trim();
            c.CustomerName = txtcustomername.Text.Trim();
            c.CustomerShortName = txtcustomercode.Text.Trim();
            c.HouseNoStreet = txthousenostreet.Text.Trim();
            //c.Id = 
            c.Industry = txtindustry.Text.Trim();
            //c.InsertedById
            //c.InsertedDate
            c.Municipality = txtmunicipality.Text.Trim();
            c.Phone = txtcustomercontactno.Text.Trim();
            c.PortalActive = ckbisportalactive.Checked;
            if (c.PortalActive != null)
            {
                if (c.PortalActive.Value == true)
                {
                    if (ViewState["vs_personnelid"] != null)
                    {
                        c.PortalActiveById = Convert.ToInt32(ViewState["vs_personnelid"]);
                        c.PortalActiveDate = System.DateTime.Now;

                    }

                }
            }
            // c.PortalActiveById
            //c.PortalActiveDate
            //c.PortalPassword
            c.PortalPassword = txtportalpassword.Text.Trim();
            c.PortalUserName = txtportalusername.Text.Trim();
            c.Province = txtprovince.Text.Trim();
            c.PSICCode = txtpsiccode.Text.Trim();
            c.Region = txtregion.Text.Trim();
            c.Remarks1 = txtremarks1.Text.Trim();
            c.Remarks2 = txtremarks2.Text.Trim();
            c.Reporting_Address = txtreportingaddresss.Text.Trim();
            c.Reporting_CustomerName = txtreportingcustomername.Text.Trim();
            //c.UpdatedById
            // c.UpdatedDate
            c.Website = txtwebsite.Text.Trim();
            c.ZipCode = txtzipcode.Text.Trim();

            string strmessage = "";



            c.InsertedDate = System.DateTime.Now;

            c.Remarks1 = txtremarks1.Text.Trim();
            c.Remarks2 = txtremarks2.Text.Trim();



            if (ViewState["vs_personnelid"] != null)
            {
                c.InsertedById = Convert.ToInt32(ViewState["vs_personnelid"]);
                c.UpdatedById = Convert.ToInt32(ViewState["vs_personnelid"]);

            }
            c.UpdatedDate = System.DateTime.Now;

            if (strmessage != "")
            {
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
                return;
            }
            try
            {
                using (DataClassesDataContext dc = new DataClassesDataContext())
                {
                    if (btnsubmit.CommandName == "save")
                    {
                        //validation //check if customer code exists
                        var valc = from cus in dc.Customers
                                    where cus.CustomerShortName == txtcustomercode.Text.Trim()
                                    select cus;
                        if (valc.Any())
                        {
                            string strmessageex = "Save; Validation; Customer Code already exists " + Environment.NewLine;
                            UCMessage.InputMessage(strmessageex);
                            UCMessage.ShowMessage();
                            return;
                        }
                        dc.Customers.InsertOnSubmit(c);
                        dc.SubmitChanges();
                    }
                    if (btnsubmit.CommandName == "update")
                    {
                        if (ViewState["vs_editid"] != null)
                        {

                            var getc = dc.Customers.Where(w => w.Id == Convert.ToInt32(ViewState["vs_editid"])).FirstOrDefault();
                            if (getc.CustomerShortName != txtcustomercode.Text.Trim())
                            {
                                //validation //check if customer code exists
                                var valc = from cus in dc.Customers.Where(w => w.CustomerShortName != getc.CustomerShortName)
                                            where cus.CustomerShortName == txtcustomercode.Text.Trim()
                                            select cus;
                                if (valc.Any())
                                {
                                    string strmessageex = "Update; Validation; Customer Code already exists " + Environment.NewLine;
                                    UCMessage.InputMessage(strmessageex);
                                    UCMessage.ShowMessage();
                                    return;
                                }
                            }
                            if (getc != null)
                            {

                                getc.AccCode = c.AccCode;
                                getc.Address1 = c.Address1;
                                getc.Address2 = c.Address2;
                                getc.Barangay = c.Barangay;
                                getc.City = c.City;
                                getc.Country = c.Country;
                                getc.CustomerContactNo = c.CustomerContactNo;
                                getc.CustomerEmail = c.CustomerEmail;
                                getc.CustomerName = c.CustomerName;
                                getc.CustomerShortName = c.CustomerShortName;
                                getc.HouseNoStreet = c.HouseNoStreet;
                                getc.Industry = c.Industry;
                                getc.Municipality = c.Municipality;
                                getc.Phone = c.Phone;
                                getc.PortalActive = c.PortalActive;
                                getc.PortalActiveById = c.PortalActiveById;
                                getc.PortalActiveDate = c.PortalActiveDate;
                                getc.PortalPassword = c.PortalPassword;
                                getc.PortalUserName = c.PortalUserName;
                                getc.Province = c.Province;
                                getc.PSICCode = c.PSICCode;
                                getc.Region = c.Region;
                            
                                getc.Reporting_Address = c.Reporting_Address;
                                getc.Reporting_CustomerName = c.Reporting_CustomerName;
                                getc.Website = c.Website;
                                getc.ZipCode = c.ZipCode;
                                getc.Active = c.Active;
                              
                                // getpr.Id
                                // getpr.InsertedById = pr.
                                // getpr.InsertedDate

                                getc.Remarks1 = c.Remarks1;
                                getc.Remarks2 = c.Remarks2;

                                getc.UpdatedById = c.UpdatedById;
                                getc.UpdatedDate = c.UpdatedDate;
                               

                                dc.SubmitChanges();
                            }
                        }

                    }
                }
                pnleditsave.Visible = false;
                pnllist.Visible = true;
                btnsearch_Click(null, null);
            }
            catch (Exception ex)
            {

                string strmessageex = "btnsubmit_Click() " + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessageex);
                UCMessage.ShowMessage();
            }


            //   UCMessage.InputMessage("submitclick");
            //  UCMessage.ShowMessage();

        }

    }

    protected void CustomTabsOne_Click(object sender, EventArgs e)
    {
        var linkButton = (LinkButton)sender;
        int activeTabIndex = 0;

        switch (linkButton.ID)
        {
            case "lbparameter":
                activeTabIndex = 0;
                break;
            case "lboptionsdetails":
                activeTabIndex = 1;
                break;
            case "LinkButton3":
                activeTabIndex = 2;
                break;
            case "LinkButton4":
                activeTabIndex = 3;
                break;
        }


        MultiView1.ActiveViewIndex = activeTabIndex;
        // Add the active CSS class to the clicked tab
        lbparameter.CssClass = "nav-link";
        lboptionsdetails.CssClass = "nav-link";
        // LinkButton2.CssClass = "nav-link";
        // LinkButton3.CssClass = "nav-link";
        //   LinkButton4.CssClass = "nav-link";
        linkButton.CssClass = "nav-link active";
    }

    protected void lnktablist_Click(object sender, EventArgs e)
    {

    }
    protected void btnaddnew_Click(object sender, EventArgs e)
    {
        InitControls();
        pnleditsave.Visible = true;
        pnllist.Visible = false;
        btnsubmit.CommandName = "save";
        btnsubmit.Text = "Save";
    }
    protected void ckbselectall_CheckedChanged(object sender, EventArgs e)
    {

    }
    private void InitControls()
    {
        txtaccountingcode.Text = "";
        txtadddress1.Text = "";
        txtaddress2.Text = "";
        txtbarangay.Text = "";
        txtCity.Text = "";
        txtcountry.Text = "";
        txtcustomercode.Text = "";
        txtcustomercontactno.Text = "";
        txtcustomeremail.Text = "";
        txtcustomername.Text = "";
        txthousenostreet.Text = "";
        txtindustry.Text = "";
        txtmunicipality.Text = "";
        txtportalpassword.Text = "";
        txtportalusername.Text = "";
        txtprovince.Text = "";
        txtpsiccode.Text = "";
        txtregion.Text = "";
        txtremarks1.Text = "";
        txtremarks2.Text = "";
        txtreportingaddresss.Text = "";
        txtreportingcustomername.Text = "";
        txtsearchcontains1.Text = "";
        txtsearchcontains2.Text = "";
        txtwebsite.Text = "";
        txtzipcode.Text = "";
       
    }
    protected void lvlist_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        Label lblid = (Label)e.Item.FindControl("lblid"); //parameterid
        if (e.CommandName == "edititem")
        {
            try
            {
                using (DataClassesDataContext dc = new DataClassesDataContext())
                {
                    var getc = dc.Customers.Where(w => w.Id == Convert.ToInt32(lblid.Text)).FirstOrDefault();
                    if (getc != null)
                    {
                        ViewState["vs_editid"] = getc.Id;
                        InitControls();
                        // getpr.Id
                        txtaccountingcode.Text = getc.AccCode;
                        txtadddress1.Text = getc.Address1;
                        txtaddress2.Text = getc.Address2;
                        txtbarangay.Text = getc.Barangay;
                        txtCity.Text = getc.City;
                        txtcountry.Text = getc.Country;
                        txtcustomercode.Text = getc.CustomerShortName;
                        txtcustomercontactno.Text = getc.CustomerContactNo;
                        txtcustomeremail.Text = getc.CustomerEmail;
                        txtcustomername.Text = getc.CustomerName;
                        txthousenostreet.Text = getc.HouseNoStreet;
                        txtindustry.Text = getc.Industry;
                        txtmunicipality.Text = getc.Municipality;
                        txtportalpassword.Text = getc.PortalPassword;
                        txtportalusername.Text = getc.PortalUserName;
                        txtprovince.Text = getc.Province;
                        txtpsiccode.Text = getc.PSICCode;
                        txtregion.Text = getc.Region;
                        txtremarks1.Text = getc.Remarks1;
                        txtremarks2.Text = getc.Remarks2;
                        txtreportingaddresss.Text = getc.Reporting_Address;
                        txtreportingcustomername.Text = getc.Reporting_CustomerName;
                        txtwebsite.Text = getc.Website;
                        txtzipcode.Text = getc.ZipCode;
               
                             
                             


                      
                        ckbactive.Checked = getc.Active != null ? getc.Active.Value : false;
                        ckbisportalactive.Checked = getc.PortalActive != null ? getc.PortalActive.Value : false;
                        //if (getpr.DefaultPersonnelId != null)
                        //{
                        //    ddlanalyst.Items.FindByValue(getpr.Id.ToString()).Selected = true;
                        //}
                        //else
                        //{
                        //    ddlanalyst.SelectedIndex = 0;
                        //}
                       
                        pnleditsave.Visible = true;
                        pnllist.Visible = false;

                        btnsubmit.CommandName = "update";
                        btnsubmit.Text = "Update";

                    }

                }
            }
            catch (Exception ex)
            {
                string strmessage = "lvlist_ItemCommand();ItemCommand=itemedit " + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
            }

        }

        if (e.CommandName == "controltypeitem")
        {
            Panel pnlcontroltype = (Panel)e.Item.FindControl("pnlcontroltype");
            ListView lvcontroltype = (ListView)e.Item.FindControl("lvcontroltype");
            DropDownList ddlcontroltype = (DropDownList)e.Item.FindControl("ddlcontroltype");
            pnlcontroltype.Visible = true;
            try
            {
                using (DataClassesDataContext dc = new DataClassesDataContext())
                {
                    var getcontroltype = from pc in dc.ParameterControlTypes.Where(w => w.ParameterId == Convert.ToInt32(lblid.Text))
                                         from pr in dc.Parameters
                                         from ctr in dc.ControlTypes
                                         from ins in dc.Personnels
                                         from upd in dc.Personnels
                                         where pc.ParameterId == pr.Id
                                         && pc.ControlTypeId == ctr.Id
                                         && pc.InsertById == ins.Id
                                         && pc.UpdatedById == upd.Id

                                         select new
                                         {
                                             pc.Active,
                                             pc.ControlTypeId,
                                             pc.Id,
                                             pc.InsertById,
                                             pc.InsertedDate,
                                             pc.ParameterId,
                                             pc.Remarks1,
                                             pc.Remarks2,
                                             pc.UpdatedById,
                                             pc.UpdatedDate,
                                             ControlTypeDesc = ctr.ControlTypeDesc,
                                             InsertedBy = ins.FirstName + " " + ins.MiddleName + " " + ins.LastName,
                                             UpdatedBy = upd.FirstName + " " + upd.MiddleName + " " + upd.LastName
                                         };
                    if (getcontroltype.Any())
                    {
                        lvcontroltype.DataSource = getcontroltype;
                        lvcontroltype.DataBind();
                    }
                    else
                    {
                        lvcontroltype.DataSource = null;
                        lvcontroltype.DataBind();
                    }
                    var getddlcontrol = dc.ControlTypes.Select(s => new
                    {
                        id = s.Id,
                        text = s.ControlTypeDesc
                    }).ToList();
                    if (getddlcontrol.Any())
                    {
                        ddlcontroltype.DataSource = getddlcontrol;
                        ddlcontroltype.DataBind();
                        ddlcontroltype.Items.Insert(0, "");
                    }
                }
            }
            catch (Exception ex)
            {

                string strmessage = "lvlist_ItemCommand();e.CommandName == controltypeitem " + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
            }

        }
        if (e.CommandName == "insertcontroltype")
        {
            Panel pnlcontroltype = (Panel)e.Item.FindControl("pnlcontroltype");
            ListView lvcontroltype = (ListView)e.Item.FindControl("lvcontroltype");
            DropDownList ddlcontroltype = (DropDownList)e.Item.FindControl("ddlcontroltype");
            try
            {
                if (ddlcontroltype.SelectedIndex != 0)
                {
                    using (DataClassesDataContext dc = new DataClassesDataContext())
                    {
                        //chgeck if exists
                        var getcontroltype = dc.ParameterControlTypes.Where(w => w.ParameterId == Convert.ToInt32(lblid.Text) && w.ControlTypeId == Convert.ToInt32(ddlcontroltype.SelectedValue)).FirstOrDefault();
                        if (getcontroltype == null)
                        {
                            var newpc = new ParameterControlType();
                            newpc.Active = true;
                            newpc.ControlTypeId = Convert.ToInt32(ddlcontroltype.SelectedValue);
                            //  newpc.Id
                            newpc.InsertById = Convert.ToInt32(ViewState["vs_personnelid"]);
                            newpc.InsertedDate = System.DateTime.Now;
                            newpc.UpdatedById = Convert.ToInt32(ViewState["vs_personnelid"]);
                            newpc.UpdatedDate = System.DateTime.Now;
                            newpc.ParameterId = Convert.ToInt32(lblid.Text);
                            // newpc.Remarks1
                            // newpc.Remarks2

                            dc.ParameterControlTypes.InsertOnSubmit(newpc);
                            dc.SubmitChanges();
                        }
                        //Rebind parametercontrol
                        var rebindcontroltype = from pc in dc.ParameterControlTypes.Where(w => w.ParameterId == Convert.ToInt32(lblid.Text))
                                                from pr in dc.Parameters
                                                from ctr in dc.ControlTypes
                                                from ins in dc.Personnels
                                                from upd in dc.Personnels
                                                where pc.ParameterId == pr.Id
                                                && pc.ControlTypeId == ctr.Id
                                                && pc.InsertById == ins.Id
                                                && pc.UpdatedById == upd.Id

                                                select new
                                                {
                                                    pc.Active,
                                                    pc.ControlTypeId,
                                                    pc.Id,
                                                    pc.InsertById,
                                                    pc.InsertedDate,
                                                    pc.ParameterId,
                                                    pc.Remarks1,
                                                    pc.Remarks2,
                                                    pc.UpdatedById,
                                                    pc.UpdatedDate,
                                                    ControlTypeDesc = ctr.ControlTypeDesc,
                                                    InsertedBy = ins.FirstName + " " + ins.MiddleName + " " + ins.LastName,
                                                    UpdatedBy = upd.FirstName + " " + upd.MiddleName + " " + upd.LastName
                                                };
                        if (rebindcontroltype.Any())
                        {
                            lvcontroltype.DataSource = rebindcontroltype;
                            lvcontroltype.DataBind();
                        }
                        else
                        {
                            lvcontroltype.DataSource = null;
                            lvcontroltype.DataBind();
                        }


                    }
                }

            }
            catch (Exception ex)
            {

                string strmessage = "lvlist_ItemCommand();e.CommandName == insertcontroltype" + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
            }
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        pnleditsave.Visible = false;
        pnllist.Visible = true;

        ViewState["vs_editid"] = null;
    }
    protected void AspNetPager1_PageChanged(object sender, EventArgs e)
    {
        btnsearch_Click(null, null);
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Bindlist();
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        txtsearchcontains1.Text = "";
        txtsearchcontains2.Text = "";
        btnsearch_Click(null, null);
    }
    protected void lvcontroltype_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        Label lblid = (Label)e.Item.FindControl("lblid");
        if (e.CommandName == "removeitem")
        {
            try
            {
                using (DataClassesDataContext dc = new DataClassesDataContext())
                {
                    var getpc = dc.ParameterControlTypes.Where(w => w.Id == Convert.ToInt32(lblid.Text)).FirstOrDefault();
                    if (getpc != null)
                    {
                        dc.ParameterControlTypes.DeleteOnSubmit(getpc);
                        dc.SubmitChanges();

                        //rebind pc

                        foreach (var i in lvlist.Items)
                        {
                            if (ListViewItemType.DataItem == i.ItemType)
                            {
                                Label prlblid = (Label)i.FindControl("lblid");
                                ListView lvsender = (ListView)sender;
                                if (getpc.ParameterId == Convert.ToInt32(prlblid.Text))
                                {
                                    var rebindcontroltype = from pc in dc.ParameterControlTypes.Where(w => w.ParameterId == getpc.ParameterId)
                                                            from pr in dc.Parameters
                                                            from ctr in dc.ControlTypes
                                                            from ins in dc.Personnels
                                                            from upd in dc.Personnels
                                                            where pc.ParameterId == pr.Id
                                                            && pc.ControlTypeId == ctr.Id
                                                            && pc.InsertById == ins.Id
                                                            && pc.UpdatedById == upd.Id

                                                            select new
                                                            {
                                                                pc.Active,
                                                                pc.ControlTypeId,
                                                                pc.Id,
                                                                pc.InsertById,
                                                                pc.InsertedDate,
                                                                pc.ParameterId,
                                                                pc.Remarks1,
                                                                pc.Remarks2,
                                                                pc.UpdatedById,
                                                                pc.UpdatedDate,
                                                                ControlTypeDesc = ctr.ControlTypeDesc,
                                                                InsertedBy = ins.FirstName + " " + ins.MiddleName + " " + ins.LastName,
                                                                UpdatedBy = upd.FirstName + " " + upd.MiddleName + " " + upd.LastName
                                                            };
                                    if (rebindcontroltype.Any())
                                    {
                                        lvsender.DataSource = rebindcontroltype;
                                        lvsender.DataBind();
                                    }
                                    else
                                    {
                                        lvsender.DataSource = null;
                                        lvsender.DataBind();
                                    }
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                string strmessage = "lvcontroltype_ItemCommand();e.CommandName == removeitem" + Environment.NewLine + ex.Message;
                UCMessage.InputMessage(strmessage);
                UCMessage.ShowMessage();
            }

        }
    }
}

